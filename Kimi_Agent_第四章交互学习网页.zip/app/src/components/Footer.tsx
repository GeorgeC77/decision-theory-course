export default function Footer() {
  return (
    <footer
      className="h-10 flex items-center justify-center"
      style={{ backgroundColor: '#2c3e50' }}
    >
      <p
        className="text-xs text-center"
        style={{ color: 'rgba(255,255,255,0.6)' }}
      >
        决策理论与方法 · 第四章 不确定型决策分析 · 交互教学平台
      </p>
    </footer>
  );
}