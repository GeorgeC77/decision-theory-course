import { useLocation } from 'react-router'
import Navbar from './Navbar'
import Sidebar from './Sidebar'

const sectionNames: Record<string, string> = {
  '/': '首页',
  '/6-1': '6.1 多阶段决策',
  '/6-2': '6.2 序列决策',
  '/6-3': '6.3 马尔可夫决策',
  '/6-4': '6.4 群体决策简介',
}

export default function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation()
  const currentPath = location.pathname
  const sectionName = sectionNames[currentPath] || '序贯决策分析'

  const breadcrumbItems =
    currentPath === '/'
      ? [{ label: '首页', path: '/' }]
      : [
          { label: '首页', path: '/' },
          { label: sectionName, path: currentPath },
        ]

  return (
    <div className="min-h-screen bg-[#f8fafc]">
      {/* Navbar */}
      <Navbar />

      {/* Main Content */}
      <div className="pt-14 flex">
        {/* Sidebar */}
        <Sidebar />

        {/* Content Area */}
        <main className="flex-1 min-h-[calc(100vh-3.5rem)]">
          {/* Breadcrumb */}
          <div className="bg-white border-b border-[#e2e8f0] px-4 lg:px-6 py-3">
            <nav className="flex items-center gap-2 text-sm text-[#64748b]">
              {breadcrumbItems.map((item, index) => (
                <span key={item.path} className="flex items-center gap-2">
                  {index > 0 && <span className="text-[#cbd5e1]">/</span>}
                  <span
                    className={
                      index === breadcrumbItems.length - 1
                        ? 'text-[#334155] font-medium'
                        : 'hover:text-[#d97706] transition-colors'
                    }
                  >
                    {item.label}
                  </span>
                </span>
              ))}
            </nav>
          </div>

          {/* Page Content */}
          <div className="page-enter p-4 lg:p-6">{children}</div>
        </main>
      </div>
    </div>
  )
}
