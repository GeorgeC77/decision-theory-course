# 修复计划

## 问题诊断

### 问题1: 侧边栏重复显示
**根因**: 4个页面组件（MultiStageDecision, SequentialDecision, MarkovDecision, GroupDecision）各自内部都导入了 Layout 并用其包裹内容，而 App.tsx 又在路由层面统一包裹了 Layout，导致 Layout 双重嵌套，Sidebar 被渲染两次。

**修复**: 从4个页面文件中移除 `import Layout` 和 `<Layout>...</Layout>` 包裹。

### 问题2: 6.3矩阵第二行第一列显示 `\n`
**根因**: MarkovDecision.tsx 第217行 `.join(" \\\\\n")` 中包含了字面量换行符 `\n`，被 KaTeX 当作普通文本渲染。

**修复**: 改为 `.join(" \\\\")` 去掉换行符。

## 执行步骤

### Stage 1: 准备工作
- 设置 final-build worktree
- 合并 page-6-1, page-6-2, page-6-3, page-6-4 分支

### Stage 2: 修复代码
- 从4个页面移除 Layout 导入和包裹
- 修复 MarkovDecision.tsx 矩阵 join 语句

### Stage 3: 构建部署
- npm run build
- 部署到生产环境
