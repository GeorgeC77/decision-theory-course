export default function Footer() {
  return (
    <footer className="border-t border-[#E2DDD6] bg-[#F7F4F0] py-4 px-6">
      <p className="text-center text-xs text-[#9E9E9E]">
        决策理论与方法 · 第三章风险型决策分析 · 交互教学平台
      </p>
    </footer>
  );
}
