import { useEffect, useRef } from 'react'
import { ArrowRight, BookOpen, Construction, AlertTriangle } from 'lucide-react'
import { cn } from '@/lib/utils'

interface Chapter {
  id: number
  title: string
  description: string
  sections: string[]
  url?: string
  comingSoon?: boolean
  notFullyReviewed?: boolean
}

const chapters: Chapter[] = [
  {
    id: 2,
    title: '确定型决策分析',
    description: '掌握确定性条件下的决策分析方法，包括货币时间价值、盈亏分析、投资评价等核心工具。',
    sections: ['货币时间价值', '盈亏决策分析', '投资评价指标', '多方案投资决策'],
    url: 'https://k6mcn5hdvliei.ok.kimi.link/',
  },
  {
    id: 3,
    title: '风险型决策分析',
    description: '学习在风险条件下的决策准则与方法，包括期望值、决策树、贝叶斯决策等分析技术。',
    sections: ['期望值准则', '决策树分析', '贝叶斯决策', '灵敏度分析', '效用理论'],
    url: 'https://opibpg7ctm3ps.ok.kimi.link/',
  },
  {
    id: 4,
    title: '不确定型决策分析',
    description: '探索不确定性条件下的各种决策准则，包括乐观、悲观、折中、后悔值等经典方法。',
    sections: ['基本概念', '乐观准则', '悲观准则', '折中准则', '后悔值准则', '等概率准则', '案例分析'],
    url: 'https://yplr4lz2l42i6.ok.kimi.link/',
  },
  {
    id: 5,
    title: '多目标决策分析',
    description: '掌握多目标决策的核心方法，包括目标准则体系、多维效用并合、AHP、DEA、模糊评价与ANP。',
    sections: ['目标准则体系', '多维效用并合', '层次分析(AHP)', 'DEA思想简化演示', '模糊综合评价', '网络分析法(ANP)'],
    url: 'https://iea54lzl7oxqm.ok.kimi.link/',
    notFullyReviewed: true,
  },
  {
    id: 6,
    title: '序贯决策分析',
    description: '研究多阶段序贯决策问题，包括多阶段决策、序列决策、马尔可夫决策和群体决策。',
    sections: ['多阶段决策', '序列决策', '马尔可夫决策', '群体决策简介'],
    url: 'https://s74f65andfhee.ok.kimi.link/',
    notFullyReviewed: true,
  },
]

function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 h-16 bg-[#1a2b4a] flex items-center shadow-md">
      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 flex items-center">
        <div className="flex items-center gap-2.5">
          <BookOpen className="w-5 h-5 text-white/90" />
          <span className="text-white font-semibold text-base tracking-wide">决策理论与方法</span>
        </div>
      </div>
    </nav>
  )
}

function HeroSection() {
  const lineRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = lineRef.current
    if (!el) return
    el.style.width = '0px'
    el.style.opacity = '0'
    const timer = setTimeout(() => {
      el.style.transition = 'width 0.8s ease-out, opacity 0.6s ease-in'
      el.style.width = '80px'
      el.style.opacity = '1'
    }, 400)
    return () => clearTimeout(timer)
  }, [])

  return (
    <section className="pt-28 pb-12 md:pt-36 md:pb-16 px-4 text-center">
      <h1 className="text-4xl md:text-5xl font-bold text-[#1e293b] tracking-tight mb-3">
        决策理论与方法
      </h1>
      <p className="text-lg md:text-xl text-[#64748b] mb-6">
        交互式学习平台
      </p>
      <div className="flex justify-center">
        <div
          ref={lineRef}
          className="h-1 rounded-full bg-[#d4a84b]"
          style={{ width: '0px', opacity: 0 }}
        />
      </div>
    </section>
  )
}

function ChapterCard({ chapter, index }: { chapter: Chapter; index: number }) {
  const cardRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = cardRef.current
    if (!el) return
    el.style.opacity = '0'
    el.style.transform = 'translateY(20px)'
    const timer = setTimeout(() => {
      el.style.transition = `opacity 0.5s ease-out ${index * 0.1}s, transform 0.5s ease-out ${index * 0.1}s`
      el.style.opacity = '1'
      el.style.transform = 'translateY(0)'
    }, 100)
    return () => clearTimeout(timer)
  }, [index])

  if (chapter.comingSoon) {
    return (
      <div
        ref={cardRef}
        className={cn(
          'relative rounded-xl bg-white shadow-md border border-gray-100 p-6',
          'opacity-60 select-none'
        )}
      >
        <div className="flex items-start justify-between mb-4">
          <span className="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-gray-200 text-gray-500 text-sm font-semibold">
            {chapter.id}
          </span>
          <div className="flex items-center gap-1.5 text-xs font-medium text-gray-400 bg-gray-100 px-2.5 py-1 rounded-full">
            <Construction className="w-3.5 h-3.5" />
            建设中
          </div>
        </div>

        <h3 className="text-xl font-semibold text-gray-400 mb-2">
          第{chapter.id}章 {chapter.title}
        </h3>
        <p className="text-sm text-gray-400 mb-5 leading-relaxed">
          {chapter.description}
        </p>

        <div className="flex flex-wrap gap-2 mb-6">
          {chapter.sections.map((section) => (
            <span
              key={section}
              className="text-xs px-2.5 py-1 rounded-full bg-gray-100 text-gray-400 font-medium"
            >
              {section}
            </span>
          ))}
        </div>

        <button
          disabled
          className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-gray-200 text-gray-400 text-sm font-medium cursor-not-allowed"
        >
          敬请期待
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    )
  }

  return (
    <div
      ref={cardRef}
      className={cn(
        'group rounded-xl bg-white shadow-md border border-gray-100 p-6',
        'hover:-translate-y-1 hover:shadow-lg transition-all duration-300'
      )}
    >
      <div className="flex items-start justify-between mb-4">
        <span className="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-[#1a2b4a] text-white text-sm font-semibold">
          {chapter.id}
        </span>
        {chapter.notFullyReviewed ? (
          <div className="flex items-center gap-1 text-xs font-medium text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-full">
            <AlertTriangle className="w-3 h-3" />
            尚未完全审核完成
          </div>
        ) : (
          <span className="text-xs text-[#64748b] bg-[#f5f2ed] px-2.5 py-1 rounded-full font-medium">
            {chapter.sections.length} 节
          </span>
        )}
      </div>

      <h3 className="text-xl font-semibold text-[#1e293b] mb-2 group-hover:text-[#1a2b4a] transition-colors">
        第{chapter.id}章 {chapter.title}
      </h3>
      <p className="text-sm text-[#64748b] mb-5 leading-relaxed">
        {chapter.description}
      </p>

      <div className="flex flex-wrap gap-2 mb-6">
        {chapter.sections.map((section) => (
          <span
            key={section}
            className="text-xs px-2.5 py-1 rounded-full bg-[#f5f2ed] text-[#64748b] font-medium border border-[#ebe7e0]"
          >
            {section}
          </span>
        ))}
      </div>

      <a
        href={chapter.url}
        target="_blank"
        rel="noopener noreferrer"
        className={cn(
          'w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg',
          'bg-[#1a2b4a] text-white text-sm font-medium',
          'hover:bg-[#243755] transition-colors duration-200'
        )}
      >
        进入学习
        <ArrowRight className="w-4 h-4" />
      </a>
    </div>
  )
}

function ChaptersGrid() {
  return (
    <section className="px-4 sm:px-6 lg:px-8 pb-20">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {chapters.map((chapter, index) => (
            <ChapterCard key={chapter.id} chapter={chapter} index={index} />
          ))}
        </div>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="border-t border-gray-200 bg-white py-6">
      <div className="max-w-7xl mx-auto px-4 text-center">
        <p className="text-sm text-[#64748b]">
          决策理论与方法 — 交互式学习平台
        </p>
      </div>
    </footer>
  )
}

export default function Home() {
  return (
    <div className="min-h-[100dvh] flex flex-col">
      <Navbar />
      <main className="flex-1">
        <HeroSection />
        <ChaptersGrid />
      </main>
      <Footer />
    </div>
  )
}
