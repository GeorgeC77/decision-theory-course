# 重构计划：准则体系图 + 效用并合3D展示

## 任务1：准则体系图重构（ECharts Tree）

### 问题
手写SVG树布局存在：
1. 连线坐标计算复杂且容易出错
2. 节点重叠问题
3. 展开/折叠动画不流畅

### 方案
使用 **ECharts Tree** 组件替换手写SVG：
- 内置成熟的 Reingold-Tilford 树布局算法
- 自动避免节点重叠
- 内置展开/折叠交互
- 内置缩放/平移
- 连线自动绘制，精确对齐
- 支持多种布局方向（自上而下、自左而右）

### 安装
`npm install echarts echarts-for-react`

### 实现
- 使用 `ReactECharts` 组件渲染树图
- 三种结构类型用不同的 `orient` 和 `layout` 配置
- 序列型：自上而下
- 非序列型：自上而下 + 自定义交叉虚线（用ECharts的graphic或markLine）
- 添加节点点击展开/折叠事件
- 添加操作按钮（添加准则、展开全部、折叠全部、重置）

## 任务2：效用并合3D展示（Three.js / R3F）

### 概念
二维效用并合：两个准则 u1 和 u2，综合效用 W = f(u1, u2)

### 四种规则的3D曲面
| 规则 | 公式 W=f(u1,u2) | 3D形状 |
|------|----------------|--------|
| 代换 | c1·u1 + c2·u2 | 平面（斜面） |
| 加法 | u1 + u2 - k | 平面（斜率不同） |
| 乘法 | u1^ρ1 · u2^ρ2 | 弯曲曲面（近原点平坦） |
| 混合 | ((1+γc1u1)(1+γc2u2)-1)/γ | S型曲面 |

### 3D场景设计
- X轴：u1（准则1效用，0-1）
- Y轴：u2（准则2效用，0-1）
- Z轴：W（综合效用，0-1）
- 曲面：半透明的彩色网格曲面
- 坐标轴标签：红色(X=u1)、绿色(Y=u2)、蓝色(Z=W)
- 参考平面：Z=0 的灰色网格底面
- 交互：鼠标拖拽旋转视角、滚轮缩放
- 滑块：控制c1/c2/ρ1/ρ2/γ/k等参数
- 当参数改变时，曲面实时更新

### 安装
`npm install three @react-three/fiber @react-three/drei @types/three`

### 实现
- 创建 `MergingSurface3D` 组件
- 使用 `Canvas` 从 @react-three/fiber
- 使用 `OrbitControls` 从 @react-three/drei 用于旋转
- 使用 `GridHelper` 作为底面参考
- 手动生成曲面顶点（51×51网格）
- 使用 `mesh` + `bufferGeometry` + `meshBasicMaterial`（wireframe模式，半透明面）
- 滑块在3D场景外部，修改state后曲面重算

## 执行顺序
两个任务独立，可以并行执行。
