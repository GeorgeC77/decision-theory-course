# 修正计划（对照教材第三版第116-119页）

## 教材公式对照

| 规则 | 教材公式（二维） | 当前代码 | 状态 |
|------|-----------------|---------|------|
| **距离规则** | W = 1 - sqrt{(1/2)[(1-u1)^2 + (1-u2)^2]} | 无 | **新增** |
| **代换规则** | W = 1 - (1-u1)(1-u2) = u1 + u2 - u1*u2 | W = sum(ci*ui) | **修正** |
| **加法规则** | W = c1*u1 + c2*u2 (c1+c2=1) | W = sum(ui) - (n-1)*k | **修正** |
| **乘法规则** | W = u1^rho1 * u2^rho2 | W = prod(ui^rhoi) | 正确 |
| **混合规则** | 1+gamma*W = (1+gamma*c1*u1)(1+gamma*c2*u2) | 同教材 | 正确 |

## 修改项

### 1. UtilityContour.tsx
- [ ] 数据区plotW === plotH（正方形），整体canvas不限
- [ ] computeW函数：修正substitution/additive公式，新增distance
- [ ] 高密度像素（GRID=160，40色带）
- [ ] Color bar完整不被吞

### 2. UtilityMerging.tsx
- [ ] RuleType增加'distance'
- [ ] RULES数组：修正substitution/additive定义，新增distance规则
- [ ] 计算逻辑：修正switch-case中的公式
- [ ] paramDesc：去掉$...$分隔符，改用纯文本+InlineMath
- [ ] 修复InlineKatex → InlineMath组件名
- [ ] 等高线参数滑块：新增distance规则（无参数），修正其他规则
- [ ] 知识卡片：更新规则描述
