declare module 'react-katex';
