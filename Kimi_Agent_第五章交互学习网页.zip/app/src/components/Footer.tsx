export default function Footer() {
  return (
    <footer
      className="w-full py-6 px-6 text-center"
      style={{ background: '#f8fafc', borderTop: '1px solid #e2e8f0' }}
    >
      <p className="text-[13px]" style={{ color: '#94a3b8' }}>
        决策理论与方法 · 第五章 多目标决策分析 · 交互教学平台
      </p>
    </footer>
  );
}
