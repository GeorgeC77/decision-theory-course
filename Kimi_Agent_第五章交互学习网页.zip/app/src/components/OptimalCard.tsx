import { CheckCircle } from 'lucide-react';

interface OptimalCardProps {
  title?: string;
  name: string;
  value?: string;
  description?: string;
}

export default function OptimalCard({
  title = '最优决策方案',
  name,
  value,
  description,
}: OptimalCardProps) {
  return (
    <div
      className="rounded-lg p-5"
      style={{
        background: '#f0fdf4',
        borderLeft: '4px solid #22c55e',
      }}
    >
      {/* Title */}
      <div className="flex items-center gap-2 mb-3">
        <CheckCircle size={18} style={{ color: '#22c55e' }} />
        <span className="text-sm font-semibold" style={{ color: '#15803d' }}>
          {title}
        </span>
      </div>

      {/* Name */}
      <div className="text-[22px] font-bold mb-2" style={{ color: '#1e293b' }}>
        {name}
      </div>

      {/* Value */}
      {value && (
        <div className="text-lg font-semibold mb-2" style={{ color: '#d97706' }}>
          {value}
        </div>
      )}

      {/* Description */}
      {description && (
        <p className="text-sm leading-relaxed" style={{ color: '#475569' }}>
          {description}
        </p>
      )}
    </div>
  );
}
